0.2.0 (Feb 18)
---
- Add more configuration options namely, ```model```, ```useSpan```, ```imageList``` and ```expanded```
- TreeNode icons
- Fixed model buliding bug

0.1.5 (Feb 13)
---
- Load tree from data Model

0.1 (Feb 11)
---
- Initial Version